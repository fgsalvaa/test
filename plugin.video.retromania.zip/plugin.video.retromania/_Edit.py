import xbmcaddon

MainBase = 'http://tinyurl.com/yagrn6sh'
addon = xbmcaddon.Addon('plugin.video.retromania')