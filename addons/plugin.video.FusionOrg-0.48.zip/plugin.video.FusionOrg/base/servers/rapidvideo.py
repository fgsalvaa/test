# -*- coding: utf-8 -*-
import re
import urllib
import urllib2
import xbmcgui


def read2(url):
    opener = urllib2.build_opener()
    opener.addheaders = [
        ('User-Agent', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.75 Safari/537.36')]
    try:
        response = opener.open(url)
        data = response.read()
    except:
        data = ''
    return data


def calidadesrapidvideo(url):
    calidades = []
    if '/d/' in url:
        url = url.replace('/d/', '/v/')
    if '/embed/' in url:
        url = url.replace('/embed/', '/v/')
    if '/e/' in url:
        url = url.replace('/e/', '/v/')
    if '?v=' in url:
        url = url.replace('?v=', '/v/')
    data = read2(url)
    if data != '':
        try:
            calidades = re.findall(
                'source\ssrc=.*?label=.([0-9]{3,}p).', data, re.IGNORECASE)
        except:
            return []

    return calidades


def urlrapidvideo(url):
    calidad = url.split('?q=')[1]
    url = url.split('?q=')[0]
    data = read2(url)
    if data != '':
        try:
            final_link = re.findall(
                'source\ssrc=.(.*?)\".*?label=.([0-9]{3,}p).', data, re.MULTILINE)
            for link in final_link:
                if calidad == link[1]:
                    final_link = link[0]
        except:
            try:
                final_link = re.findall(
                    'source src=\"(.*?)\"', data, re.MULTILINE)[0]
            except:
                messageerror()
                return ''
    else:
        messageerror()
        return ''
    header_test = {
        'user-agent': 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.75 Safari/537.36'}
    header_test = '|' + urllib.urlencode(header_test)
    return final_link + header_test


def messageerror():
    duration = 5500  # in milliseconds
    message = 'No se pudo obtener el link de RapidVideo'
    dialog = xbmcgui.Dialog()
    dialog.notification("Fusion", message,
                        xbmcgui.NOTIFICATION_INFO, duration, True)
    return
