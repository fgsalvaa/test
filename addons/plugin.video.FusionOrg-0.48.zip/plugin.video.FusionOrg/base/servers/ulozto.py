# -*- coding: utf-8 -*-
import json
import re
import requests
import urllib

headers = {}
headers['User-Agent'] = 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36'


def read2(url):
    data = 'Imposible conectar con el server'
    cookies = ''
    try:
        response = requests.get(url, headers=headers, timeout=10)
    except:
        return data, cookies
    if response.status_code == 200:
        data = response.content
        cookies = response.cookies

    return data, cookies


def read3(url):
    data = 'Imposible conectar con el server'
    cookies = ''
    try:
        response = requests.get(url, headers=headers,
                                timeout=10, allow_redirects=False)
        url = response.headers.get('location')
        response = requests.get(url, headers=headers,
                                timeout=10, allow_redirects=False)
    except:
        return data, cookies

    data = response.headers.get('location')
    cookies = response.cookies

    return data, cookies


def read4(url):
    data = 'Imposible conectar con el server'
    cookies = ''
    try:
        response = requests.get(url, headers=headers,
                                timeout=10, allow_redirects=False)
    except:
        return data, cookies

    data = response.content
    cookies = response.cookies

    return data, cookies


def urlulozto(url):
    quality = 'slow download'
    subs = []
    if '?&forgq=' in url:
        source = url.split('?&forgq=')
        quality = source[1]
        url = source[0]

    data, cookies = read2(url)
    headers = {}
    headers['User-Agent'] = 'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36'
    if data != 'Imposible conectar con el server' or not 'Page not found' in data:
        try:
            finalurlulozto = 'https:' + \
                re.findall('source\n.*src=\"(.*?)\"\n.*\n.*quality=\"' +
                           quality + '\"', data, re.IGNORECASE)[0]
        except:
            try:
                finalurlulozto = url.split(
                    '/!')[0] + re.findall('\"(\\\/watch-preview.*?)\"', data, re.IGNORECASE)[0]
                finalurlulozto = finalurlulozto.replace('\/', '/')
                data, cookies = read4(finalurlulozto)
                if 'streamPreviewUrl' in data:
                    data = json.loads(data)
                    finalurlulozto = data['streamPreviewUrl']
                    for sub in data['streamPreviewSubtitles']:
                        subs += [data['streamPreviewSubtitles'][sub]]

            except:
                finalurlulozto = url + '?do=slowDirectDownload'
                redir, cookies = read3(finalurlulozto)
                if redir != 'Imposible conectar con el server':
                    finalurlulozto = redir.replace('https', 'http')
                headers['seekable'] = 0

        headers = '|' + urllib.urlencode(headers)
        return finalurlulozto + headers, subs

    return '', subs


def calidadesulozto(url):
    calidades = []
    data, cookies = read2(url)
    if (data != 'Imposible conectar con el server' or not 'Page not found' in data or not 'nenalezena' in data or not 'nenájdená' in data or
            not 'Nie znaleziono strony' in data):
        try:
            calidades = re.findall(
                'source\n.*src=\".*?\"\n.*\n.*quality=\"(.*?)\"', data, re.IGNORECASE)
        except:
            pass
        try:
            calidades += re.findall(
                '<span>[Resolution|Rozdzielczo].*?x([0-9]{3,})<\/li>', data, re.IGNORECASE)
        except:
            pass

    return calidades
